#ifndef __WINDOWS_CCONV_H
#define __WINDOWS_CCONV_H

#if defined(i386_HOST_ARCH)
# define WINDOWS_CCONV stdcall
#elif defined(x86_64_HOST_ARCH) || defined(aarch64_HOST_ARCH)
# define WINDOWS_CCONV ccall
#else
# error Unknown mingw32 arch
#endif

#endif

